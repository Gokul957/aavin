function isValid() {

    var message = "";

    $("#divMessage").hide();
    if ($.trim($("#ddlCommunalCategory").val()) == "") {
        $("#ddlCommunalCategory").focus();
        message = "Communal Category required!!";
    }
    if ($.trim($("#txtSubCaste").val()) == "") {
        $("#txtSubCaste").focus();
        message = message + "Sub Caste required!!";
    }
    if ($.trim($("#txtCommunityCertificateNumber").val()) == "") {
        $("#txtCommunityCertificateNumber").focus();
        message = message + "Community CertificateNumber required!!";
    }
    if ($.trim($("#ddlCommunityissueDate").val()) == "") {
        $("#ddlCommunityissueDate").focus();
        message = message + "ddlCommunity issue Date required!!";
    }
    if ($.trim($("#ddlCommunityissuemonth").val()) == "") {
        $("#ddlCommunityissuemonth").focus();
        message = message + "ddlCommunity issue month required!!";
    }
    if ($.trim($("#ddlCommunityissueYear").val()) == "") {
        $("#ddlCommunityissueYear").focus();
        message = message + "ddlCommunity issue Year required!!";
    }
    if ($.trim($("#txtCommunalIssuingAuthority").val()) == "") {
        $("#txtCommunalIssuingAuthority").focus();
        message = message + "Communal Issuing Authority required!!";
    }
    if ($.trim($("#txtCommunalTaluk").val()) == "") {
        $("#txtCommunalTaluk").focus();
        message = message + "Communal Taluk required!!";
    }
    if ($.trim($("#txtCommunalDistrict").val()) == "") {
        $("#txtCommunalDistrict").focus();
        message = message + "Communal District required!!";
    }
    if ($.trim($("#chkWhethercomingunderPriority").val()) == "") {
        $("#chkWhethercomingunderPriority").focus();
        message = message + "Whether coming underPriority required!!";
    }
    if ($.trim($("#txtsslcMediumofInstruction").val()) == "") {
        $("#txtsslcMediumofInstruction").focus();
        message = message + "sslc Medium of Instruction required!!";
    }
    if ($.trim($("#txtsslcNameoftheInstitution").val()) == "") {
        $("#txtsslcNameoftheInstitution").focus();
        message = message + "sslc Name of the Institution required!!";
    }
    if ($.trim($("#txtsslcYearofPassing").val()) == "") {
        $("#txtsslcYearofPassing").focus();
        message = message + "sslc Year of Passing required!!";
    }
    if ($.trim($("#txtsslcTotalMarks").val()) == "") {
        $("#txtsslcTotalMarks").focus();
        message = message + "txt sslc Total Marks required!!";
    }
    if ($.trim($("#txtsslcMarksSecured").val()) == "") {
        $("#txtsslcMarksSecured").focus();
        message = message + "sslc Marks Secured required!!";
    }
    if ($.trim($("#txtsslcPercentage").val()) == "") {
        $("#txtsslcPercentage").focus();
        message = message + "txt sslc Percentage required!!";
    }
    if ($.trim($("#txtsslcGradeorClass").val()) == "") {
        $("#txtsslcGradeorClass").focus();
        message = message + "txt sslc Percentage required!!";
    }

    if ($.trim($("#txthscMediumofInstruction").val()) == "") {
        $("#txthscMediumofInstruction").focus();
        message = message + "hsc Medium of Instruction required!!";
    }
    if ($.trim($("#txthscNameoftheInstitution").val()) == "") {
        $("#txthscNameoftheInstitution").focus();
        message = message + "hsc Name of the Institution required!!";
    }
    if ($.trim($("#txthscYearofPassing").val()) == "") {
        $("#txthscYearofPassing").focus();
        message = message + "hsc Year of Passing required!!";
    }
    if ($.trim($("#txthscTotalMarks").val()) == "") {
        $("#txthscTotalMarks").focus();
        message = message + "txt hsc Total Marks required!!";
    }
    if ($.trim($("#txthscMarksSecured").val()) == "") {
        $("#txthscMarksSecured").focus();
        message = message + "hsc Marks Secured required!!";
    }
    if ($.trim($("#txthscPercentage").val()) == "") {
        $("#txthscPercentage").focus();
        message = message + "txt hsc Percentage required!!";
    }
    if ($.trim($("#txthscGradeorClass").val()) == "") {
        $("#txthscGradeorClass").focus();
        message = message + "txt hsc Percentage required!!";
    }


    if ($.trim($("#txtU.G.DegreeMediumofInstruction").val()) == "") {
        $("#txtU.G.DegreeMediumofInstruction").focus();
        message = message + "U.G.Degree Medium of Instruction required!!";
    }
    if ($.trim($("#txtU.G.DegreeNameoftheInstitution").val()) == "") {
        $("#txtU.G.DegreeNameoftheInstitution").focus();
        message = message + "U.G.Degree Name of the Institution required!!";
    }
    if ($.trim($("#txtU.G.DegreeYearofPassing").val()) == "") {
        $("#txtU.G.DegreeYearofPassing").focus();
        message = message + "U.G.Degree Year of Passing required!!";
    }
    if ($.trim($("#txtU.G.DegreeTotalMarks").val()) == "") {
        $("#txtU.G.DegreeTotalMarks").focus();
        message = message + "U.G.DegreeTotalMarks required!!";
    }
    if ($.trim($("#txtU.G.DegreeMarksSecured").val()) == "") {
        $("#txtU.G.DegreeMarksSecured").focus();
        message = message + "txtU.G.DegreeMarksSecured required!!";
    }
    if ($.trim($("#txtU.G.DegreePercentage").val()) == "") {
        $("#txtU.G.DegreePercentage").focus();
        message = message + "U.G.DegreePercentage required!!";
    }
    if ($.trim($("#txtU.G.DegreeGradeorClass").val()) == "") {
        $("#txtU.G.DegreeGradeorClass").focus();
        message = message + "U.G.Degree Grade or Class required!!";
    }
    if ($.trim($("#tblFeeremittance").val()) == "") {
        $("#tblFeeremittance").focus();
        message = message + " Fees Remittance Details   required!!";
    }
    if ($.trim($("#txtMobilenumber").val()) == "") {
        $("#txtMobilenumber").focus();
        message = message + " Mobile number   required!!";
    }
    if ($.trim($("#txtEmail").val()) == "") {
        $("#txtEmail").focus();
        message = message + " txtEmail  required!!";
    }
    if (message != "") {
        fnShowMessage(message);
        return false;
    }


}

function fnShowMessage(message) {
    $("#divMessage").html("<label>" + message + "</label>");
    $("#divMessage").show("slow");
}

$(document).ready(function() {

    fnLoadDates();
    fnLoadMonths();
    fnLoadYears();
});

function fnLoadDates() {
    for (var i = 1; i <= 31; i++) {
        $("#ddlCommunityissueDate").append("<option value='" + i + "'>" + i + "</option>");
        $("#ddlPriorityDate").append("<option value='" + i + "'>" + i + "</option>");

    }
}

function fnLoadMonths() {
    var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    var month = (new Date()).getMonth();
    for (; month < monthNames.length; month++) {
        $('#ddlCommunityissuemonth').append('<option>' + monthNames[month] + '</option>');
        $('#ddlPrioritymonth').append('<option>' + monthNames[month] + '</option>');

    }
}

function fnLoadYears() {

    options = "";

    for (var Y = 2020; Y >= 1960; Y--) {
        options += "<option>" + Y + "</option>";
    }
    $("#ddlCommunityissueYear").append(options);
    $("#ddlPriorityYear").append(options);
}