var UserInfo = JSON.parse(localStorage.getItem("userinfo"));
var key = UserInfo.userid
var imgurl;
var eduurl;
var comurl;
var priurl;
var expurl;
$(document).ready(function() {

    var brand = document.getElementById('btnimg');
    brand.className = 'attachment_upload';
    brand.onchange = function() {
        $("#imgpreview").show();
        document.getElementById('txtimage').value = this.value.substring(12);
    };

    // Source: http://stackoverflow.com/a/4459419/6396981
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
                $('.img-preview').attr('src', e.target.result);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#btnimg").change(function() {
        readURL(this);
    });


    var educertificate = document.getElementById('btneducertificate');
    educertificate.className = 'attachment_upload';
    educertificate.onchange = function() {
        document.getElementById('txteducertificate').value = this.value.substring(12);
    };


    var comcertificate = document.getElementById('btnCommcertificate');
    comcertificate.className = 'attachment_upload';
    comcertificate.onchange = function() {
        document.getElementById('txtCommcertificate').value = this.value.substring(12);
    };


    var pricertificate = document.getElementById('btnPricertificate');
    pricertificate.className = 'attachment_upload';
    pricertificate.onchange = function() {
        document.getElementById('txtPricertificate').value = this.value.substring(12);
    };


    var expcertificate = document.getElementById('btnExpcertificate');
    expcertificate.className = 'attachment_upload';
    expcertificate.onchange = function() {
        document.getElementById('txtExpcertificate').value = this.value.substring(12);
    };

});

function fnFilevalidation() {

    var input = document.getElementById('btnimg');
    if (!input.files) { // This is VERY unlikely, browser support is near-universal
        console.error("This browser doesn't seem to support the `files` property of file inputs.");
    } else {
        var file = input.files[0];
        var filesize = (file.size / 1024)
        if (filesize > 20) {
            alert("Chosen file is too large");
            return false;
        }
    }
    return true;
}

function fnUploadimage() {
    if ($('#btnimg').val() != '') {
        if (fnFilevalidation()) {
            const ref = firebase.storage().ref("files");
            const file = $('#btnimg').get(0).files[0];
            const name = (+new Date()) + '-' + file.name;
            const metadata = { contentType: file.type };
            const task = ref.child(name).put(file, metadata);
            task
                .then(snapshot => snapshot.ref.getDownloadURL())
                .then((url) => {
                    console.log(url);
                    document.querySelector('#btnimg').src = url;
                    var updates = {
                        "imgurl": url
                    }
                    firebase.database().ref().child("fileinfo").child(key).update(updates);
                    imgurl = url;
                    alert("New image added successfully")
                    $("#btnUploadimage").hide();
                    $("#deleteimage").show();
                    $("#btnimg").prop("disabled", true);
                    //  $('#image').remove();
                })
                .catch(console.error);
        }
    } else {
        alert('Please Select Image');
        return false;
    }


}

function fnRemoveimage() {
    var fileRef = firebase.storage().refFromURL(imgurl);
    // Delete the file using the delete() method  
    fileRef.delete().then(function() {
        // File deleted successfully 
        alert("Image deleted !. Please upload new image")
        console.log("File Deleted")
        $("#imgpreview").hide();
        $("#btnUploadimage").show();
        $("#deleteimage").hide();
        $("#txtimage").val('');
        $("#btnimg").val('');
        $("#btnimg").prop("disabled", false);
    }).catch(function(error) {
        alert("Cannot delete image something went wrong. Please try again");
    });
    var updates = {
        "imgurl": ""
    }
    firebase.database().ref().child("fileinfo").child(key).update(updates);
}


function fnEduvalidation() {

    var input = document.getElementById('btneducertificate');
    if (!input.files) {
        console.error("This browser doesn't seem to support the `files` property of file inputs.");
    } else {
        var file = input.files[0];
        var filesize = (file.size / 1024)
        if (filesize > 60) {
            alert("Chosen file is too large");
            return false;
        }
    }
    return true;
}

function fnUploadeducertificate() {
    if ($('#btneducertificate').val() != '') {
        if (fnEduvalidation()) {
            const ref = firebase.storage().ref("files");
            const file = $('#btneducertificate').get(0).files[0];
            const name = (+new Date()) + '-' + file.name;
            const metadata = { contentType: file.type };
            const task = ref.child(name).put(file, metadata);
            task
                .then(snapshot => snapshot.ref.getDownloadURL())
                .then((url) => {
                    console.log(url);
                    document.querySelector('#btneducertificate').src = url;
                    var updates = {
                        "eduurl": url
                    }
                    firebase.database().ref().child("fileinfo").child(key).update(updates);
                    eduurl = url;
                    alert("New document added successfully")
                    $("#btnUploadeducertificate").hide();
                    $("#deleteeducertificate").show();
                    $("#btneducertificate").prop("disabled", true);
                })
                .catch(console.error);
        }
    } else {
        alert('Please Select Document');
        return false;
    }


}

function fnRemoveeducertificate() {
    var fileRef = firebase.storage().refFromURL(eduurl);
    // Delete the file using the delete() method  
    fileRef.delete().then(function() {
        // File deleted successfully 
        alert("Document deleted !. Please upload new document")
        $("#btnUploadeducertificate").show();
        $("#deleteeducertificate").hide();
        $("#txteducertificate").val('');
        $("#btneducertificate").val('');
        $("#btneducertificate").prop("disabled", false);
    }).catch(function(error) {
        alert("Cannot delete document something went wrong. Please try again");
    });
    var updates = {
        "eduurl": ""
    }
    firebase.database().ref().child("fileinfo").child(key).update(updates);
}


function fnCommunityvalidation() {

    var input = document.getElementById('btnCommcertificate');
    if (!input.files) {
        console.error("This browser doesn't seem to support the `files` property of file inputs.");
    } else {
        var file = input.files[0];
        var filesize = (file.size / 1024)
        if (filesize > 60) {
            alert("Chosen file is too large");
            return false;
        }
    }
    return true;
}

function fnUploadCommcertificate() {
    if ($('#btnCommcertificate').val() != '') {
        if (fnCommunityvalidation()) {
            const ref = firebase.storage().ref("files");
            const file = $('#btnCommcertificate').get(0).files[0];
            const name = (+new Date()) + '-' + file.name;
            const metadata = { contentType: file.type };
            const task = ref.child(name).put(file, metadata);
            task
                .then(snapshot => snapshot.ref.getDownloadURL())
                .then((url) => {
                    console.log(url);
                    document.querySelector('#btnCommcertificate').src = url;
                    var updates = {
                        "comurl": url
                    }
                    firebase.database().ref().child("fileinfo").child(key).update(updates);
                    comurl = url;
                    alert("New document added successfully")
                    $("#btnUploadCommcertificate").hide();
                    $("#deleteCommcertificate").show();
                    $("#btnCommcertificate").prop("disabled", true);
                })
                .catch(console.error);
        }
    } else {
        alert('Please Select Document');
        return false;
    }


}

function fnRemoveCommcertificate() {
    var fileRef = firebase.storage().refFromURL(comurl);
    // Delete the file using the delete() method  
    fileRef.delete().then(function() {
        // File deleted successfully 
        alert("Document deleted !. Please upload new document")
        $("#btnUploadCommcertificate").show();
        $("#deleteCommcertificate").hide();
        $("#txtCommcertificate").val('');
        $("#btnCommcertificate").val('');
        $("#btnCommcertificate").prop("disabled", false);
    }).catch(function(error) {
        alert("Cannot delete document something went wrong. Please try again");
    });
    var updates = {
        "comurl": ""
    }
    firebase.database().ref().child("fileinfo").child(key).update(updates);
}


function fnPriorityvalidation() {

    var input = document.getElementById('btnPricertificate');
    if (!input.files) {
        console.error("This browser doesn't seem to support the `files` property of file inputs.");
    } else {
        var file = input.files[0];
        var filesize = (file.size / 1024)
        if (filesize > 60) {
            alert("Chosen file is too large");
            return false;
        }
    }
    return true;
}

function fnUploadPricertificate() {
    if ($('#btnPricertificate').val() != '') {
        if (fnPriorityvalidation()) {
            const ref = firebase.storage().ref("files");
            const file = $('#btnPricertificate').get(0).files[0];
            const name = (+new Date()) + '-' + file.name;
            const metadata = { contentType: file.type };
            const task = ref.child(name).put(file, metadata);
            task
                .then(snapshot => snapshot.ref.getDownloadURL())
                .then((url) => {
                    console.log(url);
                    document.querySelector('#btnPricertificate').src = url;
                    var updates = {
                        "priurl": url
                    }
                    firebase.database().ref().child("fileinfo").child(key).update(updates);
                    priurl = url;
                    alert("New document added successfully")
                    $("#btnUploadPricertificate").hide();
                    $("#deletePricertificate").show();
                    $("#btnPricertificate").prop("disabled", true);
                })
                .catch(console.error);
        }
    } else {
        alert('Please Select Document');
        return false;
    }


}

function fnRemovePricertificate() {
    var fileRef = firebase.storage().refFromURL(priurl);
    // Delete the file using the delete() method  
    fileRef.delete().then(function() {
        // File deleted successfully 
        alert("Document deleted !. Please upload new document")
        $("#btnUploadPricertificate").show();
        $("#deletePricertificate").hide();
        $("#txtPricertificate").val('');
        $("#btnPricertificate").val('');
        $("#btnPricertificate").prop("disabled", false);
    }).catch(function(error) {
        alert("Cannot delete document something went wrong. Please try again");
    });
    var updates = {
        "priurl": ""
    }
    firebase.database().ref().child("fileinfo").child(key).update(updates);
}


function fnExperiencevalidation() {

    var input = document.getElementById('btnExpcertificate');
    if (!input.files) {
        console.error("This browser doesn't seem to support the `files` property of file inputs.");
    } else {
        var file = input.files[0];
        var filesize = (file.size / 1024)
        if (filesize > 60) {
            alert("Chosen file is too large");
            return false;
        }
    }
    return true;
}

function fnUploadExpcertificate() {
    if ($('#btnExpcertificate').val() != '') {
        if (fnExperiencevalidation()) {
            const ref = firebase.storage().ref("files");
            const file = $('#btnExpcertificate').get(0).files[0];
            const name = (+new Date()) + '-' + file.name;
            const metadata = { contentType: file.type };
            const task = ref.child(name).put(file, metadata);
            task
                .then(snapshot => snapshot.ref.getDownloadURL())
                .then((url) => {
                    console.log(url);
                    document.querySelector('#btnExpcertificate').src = url;
                    var updates = {
                        "expurl": url
                    }
                    firebase.database().ref().child("fileinfo").child(key).update(updates);
                    expurl = url;
                    alert("New document added successfully")
                    $("#btnUploadExpcertificate").hide();
                    $("#deleteExpcertificate").show();
                    $("#btnExpcertificate").prop("disabled", true);
                })
                .catch(console.error);
        }
    } else {
        alert('Please Select Document');
        return false;
    }


}

function fnRemoveExpcertificate() {
    var fileRef = firebase.storage().refFromURL(expurl);
    // Delete the file using the delete() method  
    fileRef.delete().then(function() {
        // File deleted successfully 
        alert("Document deleted !. Please upload new document")
        $("#btnUploadExpcertificate").show();
        $("#deleteExpcertificate").hide();
        $("#txtExpcertificate").val('');
        $("#btnExpcertificate").val('');
        $("#btnExpcertificate").prop("disabled", false);
    }).catch(function(error) {
        alert("Cannot delete document something went wrong. Please try again");
    });
    var updates = {
        "expurl": ""
    }
    firebase.database().ref().child("fileinfo").child(key).update(updates);
}