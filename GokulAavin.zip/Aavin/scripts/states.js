var districts=[
	{
		"state": "Andaman Nicobar",
		"district": "Nicobar",
		"statetype": "Union Territory"
	},
	{
		"state": "Andaman Nicobar",
		"district": "North Middle Andaman",
		"statetype": "Union Territory"
	},
	{
		"state": "Andaman Nicobar",
		"district": "South Andaman",
		"statetype": "Union Territory"
	},
	{
		"state": "Andhra Pradesh",
		"district": "Anantapur",
		"statetype": "State"
	},
	{
		"state": "Andhra Pradesh",
		"district": "Chittoor",
		"statetype": "State"
	},
	{
		"state": "Andhra Pradesh",
		"district": "East Godavari",
		"statetype": "State"
	},
	{
		"state": "Andhra Pradesh",
		"district": "Guntur",
		"statetype": "State"
	},
	{
		"state": "Andhra Pradesh",
		"district": "Kadapa",
		"statetype": "State"
	},
	{
		"state": "Andhra Pradesh",
		"district": "Krishna",
		"statetype": "State"
	},
	{
		"state": "Andhra Pradesh",
		"district": "Kurnool",
		"statetype": "State"
	},
	{
		"state": "Andhra Pradesh",
		"district": "Nellore",
		"statetype": "State"
	},
	{
		"state": "Andhra Pradesh",
		"district": "Prakasam",
		"statetype": "State"
	},
	{
		"state": "Andhra Pradesh",
		"district": "Srikakulam",
		"statetype": "State"
	},
	{
		"state": "Andhra Pradesh",
		"district": "Visakhapatnam",
		"statetype": "State"
	},
	{
		"state": "Andhra Pradesh",
		"district": "Vizianagaram",
		"statetype": "State"
	},
	{
		"state": "Andhra Pradesh",
		"district": "West Godavari",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Anjaw",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Central Siang",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Changlang",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Dibang Valley",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "East Kameng",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "East Siang",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Kamle",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Kra Daadi",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Kurung Kumey",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Lepa Rada",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Lohit",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Longding",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Lower Dibang Valley",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Lower Siang",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Lower Subansiri",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Namsai",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Pakke Kessang",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Papum Pare",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Shi Yomi",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Tawang",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Tirap",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Upper Siang",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "Upper Subansiri",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "West Kameng",
		"statetype": "State"
	},
	{
		"state": "Arunachal Pradesh",
		"district": "West Siang",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Baksa",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Barpeta",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Biswanath",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Bongaigaon",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Cachar",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Charaideo",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Chirang",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Darrang",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Dhemaji",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Dhubri",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Dibrugarh",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Dima Hasao",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Goalpara",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Golaghat",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Hailakandi",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Hojai",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Jorhat",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Kamrup",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Kamrup Metropolitan",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Karbi Anglong",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Karimganj",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Kokrajhar",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Lakhimpur",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Majuli",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Morigaon",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Nagaon",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Nalbari",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Sivasagar",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Sonitpur",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "South Salmara-Mankachar",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Tinsukia",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "Udalguri",
		"statetype": "State"
	},
	{
		"state": "Assam",
		"district": "West Karbi Anglong",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Araria",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Arwal",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Aurangabad",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Banka",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Begusarai",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Bhagalpur",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Bhojpur",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Buxar",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Darbhanga",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "East Champaran",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Gaya",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Gopalganj",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Jamui",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Jehanabad",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Kaimur",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Katihar",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Khagaria",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Kishanganj",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Lakhisarai",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Madhepura",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Madhubani",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Munger",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Muzaffarpur",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Nalanda",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Nawada",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Patna",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Purnia",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Rohtas",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Saharsa",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Samastipur",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Saran",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Sheikhpura",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Sheohar",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Sitamarhi",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Siwan",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Supaul",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "Vaishali",
		"statetype": "State"
	},
	{
		"state": "Bihar",
		"district": "West Champaran",
		"statetype": "State"
	},
	{
		"state": "Chandigarh",
		"district": "Chandigarh",
		"statetype": "Union Territory"
	},
	{
		"state": "Chhattisgarh",
		"district": "Balod",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Baloda Bazar",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Balrampur",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Bastar",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Bemetara",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Bijapur",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Bilaspur",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Dantewada",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Dhamtari",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Durg",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Gariaband",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Gaurela Pendra Marwahi",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Janjgir Champa",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Jashpur",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Kabirdham",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Kanker",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Kondagaon",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Korba",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Koriya",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Mahasamund",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Mungeli",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Narayanpur",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Raigarh",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Raipur",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Rajnandgaon",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Sukma",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Surajpur",
		"statetype": "State"
	},
	{
		"state": "Chhattisgarh",
		"district": "Surguja",
		"statetype": "State"
	},
	{
		"state": "Dadra Nagar Haveli",
		"district": "Dadra Nagar Haveli",
		"statetype": "Union Territory"
	},
	{
		"state": "Daman Diu",
		"district": "Daman",
		"statetype": "Union Territory"
	},
	{
		"state": "Daman Diu",
		"district": "Diu",
		"statetype": "Union Territory"
	},
	{
		"state": "Delhi",
		"district": "Central Delhi",
		"statetype": "Union Territory"
	},
	{
		"state": "Delhi",
		"district": "East Delhi",
		"statetype": "Union Territory"
	},
	{
		"state": "Delhi",
		"district": "New Delhi",
		"statetype": "Union Territory"
	},
	{
		"state": "Delhi",
		"district": "North Delhi",
		"statetype": "Union Territory"
	},
	{
		"state": "Delhi",
		"district": "North East Delhi",
		"statetype": "Union Territory"
	},
	{
		"state": "Delhi",
		"district": "North West Delhi",
		"statetype": "Union Territory"
	},
	{
		"state": "Delhi",
		"district": "Shahdara",
		"statetype": "Union Territory"
	},
	{
		"state": "Delhi",
		"district": "South Delhi",
		"statetype": "Union Territory"
	},
	{
		"state": "Delhi",
		"district": "South East Delhi",
		"statetype": "Union Territory"
	},
	{
		"state": "Delhi",
		"district": "South West Delhi",
		"statetype": "Union Territory"
	},
	{
		"state": "Delhi",
		"district": "West Delhi",
		"statetype": "Union Territory"
	},
	{
		"state": "Goa",
		"district": "North Goa",
		"statetype": "State"
	},
	{
		"state": "Goa",
		"district": "South Goa",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Ahmedabad",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Amreli",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Anand",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Aravalli",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Banaskantha",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Bharuch",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Bhavnagar",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Botad",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Chhota Udaipur",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Dahod",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Dang",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Devbhoomi Dwarka",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Gandhinagar",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Gir Somnath",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Jamnagar",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Junagadh",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Kheda",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Kutch",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Mahisagar",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Mehsana",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Morbi",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Narmada",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Navsari",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Panchmahal",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Patan",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Porbandar",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Rajkot",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Sabarkantha",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Surat",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Surendranagar",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Tapi",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Vadodara",
		"statetype": "State"
	},
	{
		"state": "Gujarat",
		"district": "Valsad",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Ambala",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Bhiwani",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Charkhi Dadri",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Faridabad",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Fatehabad",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Gurugram",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Hisar",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Jhajjar",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Jind",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Kaithal",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Karnal",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Kurukshetra",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Mahendragarh",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Mewat",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Palwal",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Panchkula",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Panipat",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Rewari",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Rohtak",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Sirsa",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Sonipat",
		"statetype": "State"
	},
	{
		"state": "Haryana",
		"district": "Yamunanagar",
		"statetype": "State"
	},
	{
		"state": "Himachal Pradesh",
		"district": "Bilaspur",
		"statetype": "State"
	},
	{
		"state": "Himachal Pradesh",
		"district": "Chamba",
		"statetype": "State"
	},
	{
		"state": "Himachal Pradesh",
		"district": "Hamirpur",
		"statetype": "State"
	},
	{
		"state": "Himachal Pradesh",
		"district": "Kangra",
		"statetype": "State"
	},
	{
		"state": "Himachal Pradesh",
		"district": "Kinnaur",
		"statetype": "State"
	},
	{
		"state": "Himachal Pradesh",
		"district": "Kullu",
		"statetype": "State"
	},
	{
		"state": "Himachal Pradesh",
		"district": "Lahaul Spiti",
		"statetype": "State"
	},
	{
		"state": "Himachal Pradesh",
		"district": "Mandi",
		"statetype": "State"
	},
	{
		"state": "Himachal Pradesh",
		"district": "Shimla",
		"statetype": "State"
	},
	{
		"state": "Himachal Pradesh",
		"district": "Sirmaur",
		"statetype": "State"
	},
	{
		"state": "Himachal Pradesh",
		"district": "Solan",
		"statetype": "State"
	},
	{
		"state": "Himachal Pradesh",
		"district": "Una",
		"statetype": "State"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Anantnag",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Bandipora",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Baramulla",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Budgam",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Doda",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Ganderbal",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Jammu",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Kathua",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Kishtwar",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Kulgam",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Kupwara",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Poonch",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Pulwama",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Rajouri",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Ramban",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Reasi",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Samba",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Shopian",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Srinagar",
		"statetype": "Union Territory"
	},
	{
		"state": "Jammu Kashmir",
		"district": "Udhampur",
		"statetype": "Union Territory"
	},
	{
		"state": "Jharkhand",
		"district": "Bokaro",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Chatra",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Deoghar",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Dhanbad",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Dumka",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "East Singhbhum",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Garhwa",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Giridih",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Godda",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Gumla",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Hazaribagh",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Jamtara",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Khunti",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Koderma",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Latehar",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Lohardaga",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Pakur",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Palamu",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Ramgarh",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Ranchi",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Sahebganj",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Seraikela Kharsawan",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "Simdega",
		"statetype": "State"
	},
	{
		"state": "Jharkhand",
		"district": "West Singhbhum",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Bagalkot",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Bangalore Rural",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Bangalore Urban",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Belgaum",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Bellary",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Bidar",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Chamarajanagar",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Chikkaballapur",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Chikkamagaluru",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Chitradurga",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Dakshina Kannada",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Davanagere",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Dharwad",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Gadag",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Gulbarga",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Hassan",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Haveri",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Kodagu",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Kolar",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Koppal",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Mandya",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Mysore",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Raichur",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Ramanagara",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Shimoga",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Tumkur",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Udupi",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Uttara Kannada",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Vijayapura ",
		"statetype": "State"
	},
	{
		"state": "Karnataka",
		"district": "Yadgir",
		"statetype": "State"
	},
	{
		"state": "Kerala",
		"district": "Alappuzha",
		"statetype": "State"
	},
	{
		"state": "Kerala",
		"district": "Ernakulam",
		"statetype": "State"
	},
	{
		"state": "Kerala",
		"district": "Idukki",
		"statetype": "State"
	},
	{
		"state": "Kerala",
		"district": "Kannur",
		"statetype": "State"
	},
	{
		"state": "Kerala",
		"district": "Kasaragod",
		"statetype": "State"
	},
	{
		"state": "Kerala",
		"district": "Kollam",
		"statetype": "State"
	},
	{
		"state": "Kerala",
		"district": "Kottayam",
		"statetype": "State"
	},
	{
		"state": "Kerala",
		"district": "Kozhikode",
		"statetype": "State"
	},
	{
		"state": "Kerala",
		"district": "Malappuram",
		"statetype": "State"
	},
	{
		"state": "Kerala",
		"district": "Palakkad",
		"statetype": "State"
	},
	{
		"state": "Kerala",
		"district": "Pathanamthitta",
		"statetype": "State"
	},
	{
		"state": "Kerala",
		"district": "Thiruvananthapuram",
		"statetype": "State"
	},
	{
		"state": "Kerala",
		"district": "Thrissur",
		"statetype": "State"
	},
	{
		"state": "Kerala",
		"district": "Wayanad",
		"statetype": "State"
	},
	{
		"state": "Ladakh",
		"district": "Kargil",
		"statetype": "Union Territory"
	},
	{
		"state": "Ladakh",
		"district": "Leh",
		"statetype": "Union Territory"
	},
	{
		"state": "Lakshadweep",
		"district": "Lakshadweep",
		"statetype": "Union Territory"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Agar Malwa",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Alirajpur",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Anuppur",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Ashoknagar",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Balaghat",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Barwani",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Betul",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Bhind",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Bhopal",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Burhanpur",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Chachaura",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Chhatarpur",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Chhindwara",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Damoh",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Datia",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Dewas",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Dhar",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Dindori",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Guna",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Gwalior",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Harda",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Hoshangabad",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Indore",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Jabalpur",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Jhabua",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Katni",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Khandwa",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Khargone",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Maihar",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Mandla",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Mandsaur",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Morena",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Nagda",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Narsinghpur",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Neemuch",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Niwari",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Panna",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Raisen",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Rajgarh",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Ratlam",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Rewa",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Sagar",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Satna",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Sehore",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Seoni",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Shahdol",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Shajapur",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Sheopur",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Shivpuri",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Sidhi",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Singrauli",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Tikamgarh",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Ujjain",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Umaria",
		"statetype": "State"
	},
	{
		"state": "Madhya Pradesh",
		"district": "Vidisha",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Ahmednagar",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Akola",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Amravati",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Aurangabad",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Beed",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Bhandara",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Buldhana",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Chandrapur",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Dhule",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Gadchiroli",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Gondia",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Hingoli",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Jalgaon",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Jalna",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Kolhapur",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Latur",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Mumbai City",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Mumbai Suburban",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Nagpur",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Nanded",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Nandurbar",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Nashik",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Osmanabad",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Palghar",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Parbhani",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Pune",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Raigad",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Ratnagiri",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Sangli",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Satara",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Sindhudurg",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Solapur",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Thane",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Wardha",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Washim",
		"statetype": "State"
	},
	{
		"state": "Maharashtra",
		"district": "Yavatmal",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Bishnupur",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Chandel",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Churachandpur",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Imphal East",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Imphal West",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Jiribam",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Kakching",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Kamjong",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Kangpokpi",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Noney",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Pherzawl",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Senapati",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Tamenglong",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Tengnoupal",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Thoubal",
		"statetype": "State"
	},
	{
		"state": "Manipur",
		"district": "Ukhrul",
		"statetype": "State"
	},
	{
		"state": "Meghalaya",
		"district": "East Garo Hills",
		"statetype": "State"
	},
	{
		"state": "Meghalaya",
		"district": "East Jaintia Hills",
		"statetype": "State"
	},
	{
		"state": "Meghalaya",
		"district": "East Khasi Hills",
		"statetype": "State"
	},
	{
		"state": "Meghalaya",
		"district": "North Garo Hills",
		"statetype": "State"
	},
	{
		"state": "Meghalaya",
		"district": "Ri Bhoi",
		"statetype": "State"
	},
	{
		"state": "Meghalaya",
		"district": "South Garo Hills",
		"statetype": "State"
	},
	{
		"state": "Meghalaya",
		"district": "South West Garo Hills",
		"statetype": "State"
	},
	{
		"state": "Meghalaya",
		"district": "South West Khasi Hills",
		"statetype": "State"
	},
	{
		"state": "Meghalaya",
		"district": "West Garo Hills",
		"statetype": "State"
	},
	{
		"state": "Meghalaya",
		"district": "West Jaintia Hills",
		"statetype": "State"
	},
	{
		"state": "Meghalaya",
		"district": "West Khasi Hills",
		"statetype": "State"
	},
	{
		"state": "Mizoram",
		"district": "Aizawl",
		"statetype": "State"
	},
	{
		"state": "Mizoram",
		"district": "Champhai",
		"statetype": "State"
	},
	{
		"state": "Mizoram",
		"district": "Kolasib",
		"statetype": "State"
	},
	{
		"state": "Mizoram",
		"district": "Lawngtlai",
		"statetype": "State"
	},
	{
		"state": "Mizoram",
		"district": "Lunglei",
		"statetype": "State"
	},
	{
		"state": "Mizoram",
		"district": "Mamit",
		"statetype": "State"
	},
	{
		"state": "Mizoram",
		"district": "Saiha",
		"statetype": "State"
	},
	{
		"state": "Mizoram",
		"district": "Serchhip",
		"statetype": "State"
	},
	{
		"state": "Nagaland",
		"district": "Dimapur",
		"statetype": "State"
	},
	{
		"state": "Nagaland",
		"district": "Kiphire",
		"statetype": "State"
	},
	{
		"state": "Nagaland",
		"district": "Kohima",
		"statetype": "State"
	},
	{
		"state": "Nagaland",
		"district": "Longleng",
		"statetype": "State"
	},
	{
		"state": "Nagaland",
		"district": "Mokokchung",
		"statetype": "State"
	},
	{
		"state": "Nagaland",
		"district": "Mon",
		"statetype": "State"
	},
	{
		"state": "Nagaland",
		"district": "Noklak",
		"statetype": "State"
	},
	{
		"state": "Nagaland",
		"district": "Peren",
		"statetype": "State"
	},
	{
		"state": "Nagaland",
		"district": "Phek",
		"statetype": "State"
	},
	{
		"state": "Nagaland",
		"district": "Tuensang",
		"statetype": "State"
	},
	{
		"state": "Nagaland",
		"district": "Wokha",
		"statetype": "State"
	},
	{
		"state": "Nagaland",
		"district": "Zunheboto",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Angul",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Balangir",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Balasore",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Bargarh",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Bhadrak",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Boudh",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Cuttack",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Debagarh",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Dhenkanal",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Gajapati",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Ganjam",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Jagatsinghpur",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Jajpur",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Jharsuguda",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Kalahandi",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Kandhamal",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Kendrapara",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Kendujhar",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Khordha",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Koraput",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Malkangiri",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Mayurbhanj",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Nabarangpur",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Nayagarh",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Nuapada",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Puri",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Rayagada",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Sambalpur",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Subarnapur",
		"statetype": "State"
	},
	{
		"state": "Odisha",
		"district": "Sundergarh",
		"statetype": "State"
	},
	{
		"state": "Puducherry",
		"district": "Karaikal",
		"statetype": "Union Territory"
	},
	{
		"state": "Puducherry",
		"district": "Mahe",
		"statetype": "Union Territory"
	},
	{
		"state": "Puducherry",
		"district": "Puducherry",
		"statetype": "Union Territory"
	},
	{
		"state": "Puducherry",
		"district": "Yanam",
		"statetype": "Union Territory"
	},
	{
		"state": "Punjab",
		"district": "Amritsar",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Barnala",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Bathinda",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Faridkot",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Fatehgarh Sahib",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Fazilka",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Firozpur",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Gurdaspur",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Hoshiarpur",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Jalandhar",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Kapurthala",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Ludhiana",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Mansa",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Moga",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Mohali",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Muktsar",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Pathankot",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Patiala",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Rupnagar",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Sangrur",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Shaheed Bhagat Singh Nagar",
		"statetype": "State"
	},
	{
		"state": "Punjab",
		"district": "Tarn Taran",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Ajmer",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Alwar",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Banswara",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Baran",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Barmer",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Bharatpur",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Bhilwara",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Bikaner",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Bundi",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Chittorgarh",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Churu",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Dausa",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Dholpur",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Dungarpur",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Hanumangarh",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Jaipur",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Jaisalmer",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Jalore",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Jhalawar",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Jhunjhunu",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Jodhpur",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Karauli",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Kota",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Nagaur",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Pali",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Pratapgarh",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Rajsamand",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Sawai Madhopur",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Sikar",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Sirohi",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Sri Ganganagar",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Tonk",
		"statetype": "State"
	},
	{
		"state": "Rajasthan",
		"district": "Udaipur",
		"statetype": "State"
	},
	{
		"state": "Sikkim",
		"district": "East Sikkim",
		"statetype": "State"
	},
	{
		"state": "Sikkim",
		"district": "North Sikkim",
		"statetype": "State"
	},
	{
		"state": "Sikkim",
		"district": "South Sikkim",
		"statetype": "State"
	},
	{
		"state": "Sikkim",
		"district": "West Sikkim",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Ariyalur",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Chengalpattu",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Chennai",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Coimbatore",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Cuddalore",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Dharmapuri",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Dindigul",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Erode",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Kallakurichi",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Kanchipuram",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Kanyakumari",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Karur",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Krishnagiri",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Madurai",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Mayiladuthurai ",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Nagapattinam",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Namakkal",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Nilgiris",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Perambalur",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Pudukkottai",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Ramanathapuram",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Ranipet",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Salem",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Sivaganga",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Tenkasi",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Thanjavur",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Theni",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Thoothukudi",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Tiruchirappalli",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Tirunelveli",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Tirupattur",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Tiruppur",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Tiruvallur",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Tiruvannamalai",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Tiruvarur",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Vellore",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Viluppuram",
		"statetype": "State"
	},
	{
		"state": "Tamil Nadu",
		"district": "Virudhunagar",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Adilabad",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Bhadradri Kothagudem",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Hyderabad",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Jagtial",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Jangaon",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Jayashankar",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Jogulamba",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Kamareddy",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Karimnagar",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Khammam",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Komaram Bheem",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Mahabubabad",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Mahbubnagar",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Mancherial",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Medak",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Medchal",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Mulugu",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Nagarkurnool",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Nalgonda",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Narayanpet",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Nirmal",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Nizamabad",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Peddapalli",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Rajanna Sircilla",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Ranga Reddy",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Sangareddy",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Siddipet",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Suryapet",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Vikarabad",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Wanaparthy",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Warangal Rural",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Warangal Urban",
		"statetype": "State"
	},
	{
		"state": "Telangana",
		"district": "Yadadri Bhuvanagiri",
		"statetype": "State"
	},
	{
		"state": "Tripura",
		"district": "Dhalai",
		"statetype": "State"
	},
	{
		"state": "Tripura",
		"district": "Gomati",
		"statetype": "State"
	},
	{
		"state": "Tripura",
		"district": "Khowai",
		"statetype": "State"
	},
	{
		"state": "Tripura",
		"district": "North Tripura",
		"statetype": "State"
	},
	{
		"state": "Tripura",
		"district": "Sepahijala",
		"statetype": "State"
	},
	{
		"state": "Tripura",
		"district": "South Tripura",
		"statetype": "State"
	},
	{
		"state": "Tripura",
		"district": "Unakoti",
		"statetype": "State"
	},
	{
		"state": "Tripura",
		"district": "West Tripura",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Agra",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Aligarh",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Ambedkar Nagar",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Amethi",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Amroha",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Auraiya",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Ayodhya",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Azamgarh",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Baghpat",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Bahraich",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Ballia",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Balrampur",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Banda",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Barabanki",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Bareilly",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Basti",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Bhadohi",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Bijnor",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Budaun",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Bulandshahr",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Chandauli",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Chitrakoot",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Deoria",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Etah",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Etawah",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Farrukhabad",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Fatehpur",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Firozabad",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Gautam Buddha Nagar",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Ghaziabad",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Ghazipur",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Gonda",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Gorakhpur",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Hamirpur",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Hapur",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Hardoi",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Hathras",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Jalaun",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Jaunpur",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Jhansi",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Kannauj",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Kanpur Dehat",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Kanpur Nagar",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Kasganj",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Kaushambi",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Kheri",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Kushinagar",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Lalitpur",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Lucknow",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Maharajganj",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Mahoba",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Mainpuri",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Mathura",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Mau",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Meerut",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Mirzapur",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Moradabad",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Muzaffarnagar",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Pilibhit",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Pratapgarh",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Prayagraj",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Raebareli",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Rampur",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Saharanpur",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Sambhal",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Sant Kabir Nagar",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Shahjahanpur",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Shamli",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Shravasti",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Siddharthnagar",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Sitapur",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Sonbhadra",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Sultanpur",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Unnao",
		"statetype": "State"
	},
	{
		"state": "Uttar Pradesh",
		"district": "Varanasi",
		"statetype": "State"
	},
	{
		"state": "Uttarakhand",
		"district": "Almora",
		"statetype": "State"
	},
	{
		"state": "Uttarakhand",
		"district": "Bageshwar",
		"statetype": "State"
	},
	{
		"state": "Uttarakhand",
		"district": "Chamoli",
		"statetype": "State"
	},
	{
		"state": "Uttarakhand",
		"district": "Champawat",
		"statetype": "State"
	},
	{
		"state": "Uttarakhand",
		"district": "Dehradun",
		"statetype": "State"
	},
	{
		"state": "Uttarakhand",
		"district": "Haridwar",
		"statetype": "State"
	},
	{
		"state": "Uttarakhand",
		"district": "Nainital",
		"statetype": "State"
	},
	{
		"state": "Uttarakhand",
		"district": "Pauri",
		"statetype": "State"
	},
	{
		"state": "Uttarakhand",
		"district": "Pithoragarh",
		"statetype": "State"
	},
	{
		"state": "Uttarakhand",
		"district": "Rudraprayag",
		"statetype": "State"
	},
	{
		"state": "Uttarakhand",
		"district": "Tehri",
		"statetype": "State"
	},
	{
		"state": "Uttarakhand",
		"district": "Udham Singh Nagar",
		"statetype": "State"
	},
	{
		"state": "Uttarakhand",
		"district": "Uttarkashi",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Alipurduar",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Bankura",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Birbhum",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Cooch Behar",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Dakshin Dinajpur",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Darjeeling",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Hooghly",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Howrah",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Jalpaiguri",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Jhargram",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Kalimpong",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Kolkata",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Malda",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Murshidabad",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Nadia",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "North 24 Parganas",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Paschim Bardhaman",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Paschim Medinipur",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Purba Bardhaman",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Purba Medinipur",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Purulia",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "South 24 Parganas",
		"statetype": "State"
	},
	{
		"state": "West Bengal",
		"district": "Uttar Dinajpur",
		"statetype": "State"
	}
]

const States=[
        {
            "state": "Andaman Nicobar",
            "value": "Andaman Nicobar"
        },
        {
            "state": "Andhra Pradesh",
            "value": "Andhra Pradesh"
        },
        {
            "state": "Arunachal Pradesh",
            "value": "Arunachal Pradesh"
        },
        {
            "state": "Assam",
            "value": "Assam"
        },
        {
            "state": "Bihar",
            "value": "Bihar"
        },
        {
            "state": "Chandigarh",
            "value": "Chandigarh"
        },
        {
            "state": "Dadra Nagar Haveli",
            "value": "Dadra Nagar Haveli"
        },
        {
            "state": "Daman Diu",
            "value": "Daman Diu"
        },
        {
            "state": "Delhi",
            "value": "Delhi"
        },
        {
            "state": "Goa",
            "value": "Goa"
        },
        {
            "state": "Gujarat",
            "value": "Gujarat"
        },
        {
            "state": "Haryana",
            "value": "Haryana"
        },
        {
            "state": "Himachal Pradesh",
            "value": "Himachal Pradesh"
        },
        {
            "state": "Jammu Kashmir",
            "value": "Jammu Kashmir"
        },
        {
            "state": "Jharkhand",
            "value": "Jharkhand"
        },
        {
            "state": "Karnataka",
            "value": "Karnataka"
        },
        {
            "state": "Kerala",
            "value": "Kerala"
        },
        {
            "state": "Ladakh",
            "value": "Ladakh"
        },
        {
            "state": "Lakshadweep",
            "value": "Lakshadweep"
        },
        {
            "state": "Madhya Pradesh",
            "value": "Madhya Pradesh"
        },
        {
            "state": "Maharashtra",
            "value": "Maharashtra"
        },
        {
            "state": "Manipur",
            "value": "Manipur"
        },
        {
            "state": "Meghalaya",
            "value": "Meghalaya"
        },
        {
            "state": "Mizoram",
            "value": "Mizoram"
        },
        {
            "state": "Nagaland",
            "value": "Nagaland"
        },
        {
            "state": "Odisha",
            "value": "Odisha"
        },
        {
            "state": "Puducherry",
            "value": "Puducherry"
        },
        {
            "state": "Punjab",
            "value": "Punjab"
        },
        {
            "state": "Rajasthan",
            "value": "Rajasthan"
        },
        {
            "state": "Sikkim",
            "value": "Sikkim"
        },
        {
            "state": "Tamil Nadu",
            "value": "Tamil Nadu"
        },
        {
            "state": "Telangana",
            "value": "Telangana"
        },
        {
            "state": "Tripura",
            "value": "Tripura"
        },
        {
            "state": "Uttarakhand",
            "value": "Uttarakhand"
        },
        {
            "state": "West Bengal",
            "value": "West Bengal"
        }
]
