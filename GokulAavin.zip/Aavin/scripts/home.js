function fnManager(ev) {
    $("#divMainContent").hide();
    var post = "Manager(Engineer)";
    $.cookie('Manager', post);
    $("#divMainContent").empty().load("appform.html", function() {
        $("#divMainContent").show("slow");
    });
    return false;
}

function fnManagerDeputy(ev) {
    $("#divMainContent").hide();
    var post = "DeputyManager(Marketing)";
    $.cookie('Manager', post);
    $("#divMainContent").empty().load("appform.html", function() {
        $("#divMainContent").show("slow");
    });
    return false;
}

function fnuploadimage(ev) {
    $("#divMainContent").hide();
    $("#divMainContent").empty().load("documentupload.html", function() {
        $("#divMainContent").show("slow");
    });
    return false;
}