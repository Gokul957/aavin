$(document).ready(function() {
    post = $.cookie('Manager');
    $.removeCookie('Manager');
    $("#title").html("<label>" + "Application Form  for " + post + "</label>");
    fnPreload();
    fnLoadStates();
    fnbinddata();
});

function fnLoadStates() {

    for (var i = 0; i < States.length; i++) {
        $("#ddlPState").append("<option value='" + States[i].value + "'>" + States[i].state.toUpperCase() + "</option>");
    }
    $("#ddlPState").on("change", function() {
        $("#ddlPDistrict").empty();
        for (var i = 0; i < districts.length; i++) {
            if ($.trim(this.value.toLowerCase()) == districts[i].state.toLowerCase()) {
                $("#ddlPDistrict").append("<option value='" + districts[i].district + "'>" + districts[i].district.toUpperCase() + "</option>");
            }
        }
    });
    for (var i = 0; i < States.length; i++) {
        $("#ddlState").append("<option value='" + States[i].value + "'>" + States[i].state.toUpperCase() + "</option>");
    }
    $("#ddlState").on("change", function() {
        $("#ddlDistrict").empty();
        for (var i = 0; i < districts.length; i++) {
            if ($.trim(this.value.toLowerCase()) == districts[i].state.toLowerCase()) {
                $("#ddlDistrict").append("<option value='" + districts[i].district + "'>" + districts[i].district.toUpperCase() + "</option>");
            }
        }
    });
}



function fnPreload() {
    var UserInfo = JSON.parse(localStorage.getItem("userinfo"));
    var ApplicantName = (UserInfo.applicantname).toUpperCase();
    var MobileNumber = (UserInfo.mobile);
    var Emailid = (UserInfo.emailid);
    $("#txtNameoftheCandidate").val(ApplicantName);
    $("#txtMobilenumber").val(MobileNumber);
    $("#txtEmailid").val(Emailid);
}

function fnbinddata() {
    var UserInfo = JSON.parse(localStorage.getItem("userinfo"));
    var key = UserInfo.userid
    var applicationform = JSON.parse(localStorage.getItem("Form"));
    if (applicationform != null) {
        for (var i = 0; i < applicationform.length; i++)
            if (applicationform[i].key == key) {
                var date = (applicationform[i].dateofbirth).substring(0, 2)
                date = parseInt(date);
                var month = (applicationform[i].dateofbirth).substring(3, 5)
                month = parseInt(month);
                var year = applicationform[i].dateofbirth.substring(6, 10)
                year = parseInt(year);
                $("#ddlGender").val(applicationform[i].gender)
                $("#ddlDate").val(date);
                $("#ddlmonth").val(month);
                $("#ddlYear").val(year);
                $("#txtAge").val(applicationform[i].age);
                $("#txtFatherName").val(applicationform[i].fathername);
                $("#txtMotherName").val(applicationform[i].mothername);
                $("#ddlMaritalStatus").val(applicationform[i].maritalstatus);
                $("#txtSpouseName").val(applicationform[i].spousename);
                $("#ddlFemaleApplicant").val(applicationform[i].ifapplicantisfemale);
                $("#txtPlaceofBirth").val(applicationform[i].placeofbirth);
                $("#txtNativeDistrictandState").val(applicationform[i].nativedistrictandstate);
                $("#txtOtherState").val(applicationform[i].otherstatename);
                $("#txtMotherTongue").val(applicationform[i].mothertongue);
                $("#txtOtherlanguagesKnown").val(applicationform[i].otherknownlanguage);
                $("#ddlNationality").val(applicationform[i].nationality);
                $("#txtReligion").val(applicationform[i].religion);
                $("#txtDoorNo").val(applicationform[i].cdoorno);
                $("#txtStreetName").val(applicationform[i].cstreetname);
                $("#txtCityorVillage").val(applicationform[i].ccityorvillage);
                $("#ddlState").val(applicationform[i].cstate);
                $("#ddlState").change();
                $("#ddlDistrict").val(applicationform[i].cdistrict);
                $("#txtPincode").val(applicationform[i].cpincode);
                if (applicationform[i].sameaddress == true) {
                    $('#chkcommunicationaddress').prop('checked', true);
                } else {
                    $('#chkcommunicationaddress').prop('checked', false);
                }
                $("#txtPDoorNo").val(applicationform[i].pdoorno);
                $("#txtPStreetName").val(applicationform[i].pstreetname);
                $("#txtPCityorVillage").val(applicationform[i].pcityorvillage);
                $("#ddlPState").val(applicationform[i].pstate);
                $("#ddlPState").change();
                $("#ddlPDistrict").val(applicationform[i].pdistrict);
                $("#txtPPincode").val(applicationform[i].ppincode);
            }
    }
}


function isValid() {

    var message = "";

    $("#divMessage").hide();
    if ($.trim($("#txtNameoftheCandidate").val()) == "") {
        $("#txtNameoftheCandidate").focus();
        message = "Candidate Name required!!";
    }
    if ($.trim($("#ddlGender").val()) == 0) {
        $("#ddlGender").focus();
        message = message + "<br>Select Gender!!";
    }
    if ($.trim($("#ddlDate").val()) == 0) {
        $("#ddlDate").focus();
        message = message + "<br>Select Date in Date of Birth!!";
    }
    if ($.trim($("#ddlmonth").val()) == 0) {
        $("#ddlmonth").focus();
        message = message + "<br>Select Month in Date of Birth!!";
    }
    if ($.trim($("#ddlYear").val()) == 0) {
        $("#ddlYear").focus();
        message = message + "<br>Select Year in Date of Birth!!";
    }
    if ($.trim($("#txtAge").val()) == "") {
        $("#txtAge").focus();
        message = message + "<br>Age Required!!";
    }
    if ($.trim($("#txtFatherName").val()) == "") {
        $("#txtFatherName").focus();
        message = message + "<br>Father's Name Required!!";
    }
    if ($.trim($("#txtMotherName").val()) == "") {
        $("#txtMotherName").focus();
        message = message + "<br>Mother's Name Required!!";
    }
    if ($.trim($("#ddlMaritalStatus").val()) == 0) {
        $("#ddlMaritalStatus").focus();
        message = message + "<br>Select Marital Status!!";
    }
    if ($.trim($("#txtPlaceofBirth").val()) == "") {
        $("#txtPlaceofBirth").focus();
        message = message + "<br>Place of Birth Required!!";
    }
    if ($.trim($("#txtNativeDistrictandState").val()) == "") {
        $("#txtNativeDistrictandState").focus();
        message = message + "<br>Native District and State Required!!";
    }
    if ($.trim($("#txtMotherTongue").val()) == "") {
        $("#txtMotherTongue").focus();
        message = message + "<br>Mother Tounge Required!!";
    }
    if ($.trim($("#ddlNationality").val()) == 0) {
        $("#ddlNationality").focus();
        message = message + "<br>Select Nationality!!";
    }
    if ($.trim($("#txtReligion").val()) == "") {
        $("#txtReligion").focus();
        message = message + "<br>Religion Required!!";
    }
    if ($.trim($("#txtDoorNo").val()) == "") {
        $("#txtDoorNo").focus();
        message = message + "<br>Door Number Required!!";
    }
    if ($.trim($("#txtStreetName").val()) == "") {
        $("#txtStreetName").focus();
        message = message + "<br>Street Name Required!!";
    }
    if ($.trim($("#txtCityorVillage").val()) == "") {
        $("#txtCityorVillage").focus();
        message = message + "<br>City/Village Required!!";
    }
    if ($.trim($("#ddlDistrict").val()) == 0) {
        $("#ddlDistrict").focus();
        message = message + "<br>District in Communication Address Required!!";
    }
    if ($.trim($("#ddlState").val()) == 0) {
        $("#ddlState").focus();
        message = message + "<br>State in Communication Address Required!!";
    }
    if ($.trim($("#txtPincode").val()) == "") {
        $("#txtPincode").focus();
        message = message + "<br>Pincode Required!!";
    }
    if (message != "") {
        message = "(Please fill the detail(s) in (*) marked box)";
        fnShowMessage(message);
        return false;
    }

    var date = parseInt($("#ddlDate").val())
    if (date < 10) {
        date.toString();
        date = '0' + date
    } else {
        date.toString();
    }
    var month = parseInt($("#ddlmonth").val())
    if (month < 10) {
        month.toString();
        month = '0' + month
    } else {
        month.toString();
    }
    var DateofBirth = date + "/" + month + "/" + $("#ddlYear").val();
    var sameadd;
    if ($('#chkcommunicationaddress').is(':checked')) {
        sameadd = true;
    } else {
        sameadd = false;
    }
    var updates = {
        "candidatename": $("#txtNameoftheCandidate").val(),
        "gender": parseInt($("#ddlGender").val()),
        "dateofbirth": DateofBirth,
        "age": parseInt($("#txtAge").val()),
        "fathername": $("#txtFatherName").val(),
        "mothername": $("#txtMotherName").val(),
        "maritalstatus": parseInt($("#ddlMaritalStatus").val()),
        "spousename": $("#txtSpouseName").val(),
        "ifapplicantisfemale": parseInt($("#ddlFemaleApplicant").val()),
        "placeofbirth": $("#txtPlaceofBirth").val(),
        "nativedistrictandstate": $("#txtNativeDistrictandState").val(),
        "otherstatename": $("#txtOtherState").val(),
        "mothertongue": $("#txtMotherTongue").val(),
        "otherknownlanguage": $("#txtOtherlanguagesKnown").val(),
        "nationality": parseInt($("#ddlNationality").val()),
        "religion": $("#txtReligion").val(),
        "cdoorno": $("#txtDoorNo").val(),
        "cstreetname": $("#txtStreetName").val(),
        "ccityorvillage": $("#txtCityorVillage").val(),
        "cdistrict": $("#ddlDistrict").val(),
        "cstate": $("#ddlState").val(),
        "cpincode": $("#txtPincode").val(),
        "sameaddress": sameadd,
        "pdoorno": $("#txtPDoorNo").val(),
        "pstreetname": $("#txtPStreetName").val(),
        "pcityorvillage": $("#txtPCityorVillage").val(),
        "pdistrict": $("#ddlPDistrict").val(),
        "pstate": $("#ddlPState").val(),
        "ppincode": $("#txtPPincode").val()
    }
    var UserInfo = JSON.parse(localStorage.getItem("userinfo"));

    var key = UserInfo.userid
    if (key != undefined) {

        firebase.database().ref().child("ApplicationForm").child(key).update(updates);
        //$.dialog.alert("Updated Successfully");
        alert("Application Saved successfully");

        forms = [];
        localStorage.removeItem("Form");
        var applicationform = firebase.database().ref().child("ApplicationForm");
        applicationform.once('value', function(snapshot) {
                snapshot.forEach(function(childSnapshot) {
                    let form = childSnapshot.val();
                    if (form != null) {
                        form.key = childSnapshot.key;
                        forms.push(form);
                    }
                });
                if (forms.length > 0) {
                    localStorage.setItem("Form", JSON.stringify(forms));
                }

            },
            function(error) {
                if (error) {
                    console.error(error);
                    // The callback failed.
                } else {

                }
            });
    }


    $("#divMainContent").hide();
    $("#divMainContent").empty().load("education.html", function() {
        $("#divMainContent").show("slow");
    });
    return false;
}

function fnShowMessage(message) {
    $("#divMessage").html("<label>" + message + "</label>");
    $("#divMessage").show("slow");
}

$('#chkcommunicationaddress').change(function() {
    if ($('#chkcommunicationaddress').is(':checked')) {
        $("#txtPDoorNo").val($("#txtDoorNo").val());
        $("#txtPStreetName").val($("#txtStreetName").val());
        $("#txtPCityorVillage").val($("#txtCityorVillage").val());
        $("#ddlPDistrict").val($("#txtDistrict").val());
        $("#ddlPState").val($("#txtState").val());
        $("#txtPPincode").val($("#txtPincode").val());
    } else {
        $("#txtPDoorNo").val('')
        $("#txtPStreetName").val('')
        $("#txtPCityorVillage").val('')
        $("#ddlPDistrict").val('')
        $("#ddlPState").val('')
        $("#txtPPincode").val('')
    }
});